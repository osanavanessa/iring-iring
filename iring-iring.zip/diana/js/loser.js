loseGame = {
	create: function (){
		game.physics.startSystem(Phaser.Physics.ARCADE);
			 game.add.tileSprite(0, 0,850,800, 'bg2');
		
         menuText = game.add.text (500,10, "Game Over\nScore: "+score, {"fill" : "green"});
		menuText.scale.x =1.50;
		menuText.scale.y =1.50;
	
	},

	update: function(){
		
	

   }	
	
}

