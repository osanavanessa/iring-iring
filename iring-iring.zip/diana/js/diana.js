menuGame = {
	create: function (){
	 game.add.tileSprite(0, 0,900,600, 'abt');

		

	},
	update: function(){
	


	}
}