winGame = {
	create: function (){
		game.physics.startSystem(Phaser.Physics.ARCADE);
		 game.add.tileSprite(0, 0,900,600, 'grats');
		
         menuText = game.add.text (620,20, "Magsaya^_^\nScore: "+score, {"fill" : "blue"});
		menuText.scale.x =1;
		menuText.scale.y =1;
	
	},

	update: function(){
		
	

   }	
	
}

